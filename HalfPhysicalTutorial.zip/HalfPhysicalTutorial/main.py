import os
import json
import logging
import asyncio
import aiohttp
from aiogram import Bot, Dispatcher, types, Router
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.strategy import FSMStrategy
from flask import Flask
from threading import Thread

# Your bot token
BOT_TOKEN = '7625064329:AAGAIti8eJZoLYHwFJDWF0mK_fCil-kFCk8'

# File to store authorized group IDs
AUTHORIZED_GROUPS_FILE = 'authorized_groups.txt'

# File to store API settings
API_SETTINGS_FILE = 'api_settings.json'

# File to store promotion messages for groups
PROMOTIONS_FILE = 'promotions.json'

# File to store VIP users
VIP_USERS_FILE = 'vip_users.json'

# File to store bot analytics
ANALYTICS_FILE = 'bot_analytics.json'

# Admin user ID
ADMIN_USERS = [6941108933]  # Replace with your Telegram user ID

# Vice Admin user IDs - Can only use setpromotion command
VICE_ADMIN_USERS = [8064802571]  # Add vice admin IDs here

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()  # Initialize storage
dp = Dispatcher(storage=storage, fsm_strategy=FSMStrategy.USER_IN_CHAT)

# Create a router
router = Router()
dp.include_router(router)  # Include the router in the dispatcher

# Logging setup
logging.basicConfig(level=logging.INFO)

# Flask app to keep the bot alive
app = Flask('')


@app.route('/')
def home():
    return "Bot is running!"


def run():
    app.run(host='0.0.0.0', port=8080)


def keep_alive():
    # Start the Flask server in a separate thread
    t = Thread(target=run)
    t.start()


# Function to load authorized groups from the file
def load_authorized_groups():
    if not os.path.exists(AUTHORIZED_GROUPS_FILE):
        with open(AUTHORIZED_GROUPS_FILE, 'w') as f:
            pass  # Create the file if it doesn't exist
    with open(AUTHORIZED_GROUPS_FILE, 'r') as f:
        groups = f.read().splitlines()
    return [int(group) for group in groups if group]


# Function to save authorized groups to the file
def save_authorized_groups(groups):
    with open(AUTHORIZED_GROUPS_FILE, 'w') as f:
        f.write('\n'.join(map(str, groups)))


# Function to load API settings from the file
def load_api_settings():
    if not os.path.exists(API_SETTINGS_FILE):
        # Default API settings
        default_settings = {
            'L1':
            'https://freefire-virusteam.vercel.app/ind/visit?key=7day@apivirusteam&uid={uid}&sl=50',
            'L2':
            'https://leader-krishna-api.vercel.app/spam_visit?uid={uid}&region=ind&key=teamXKrishna',
            'L3':
            'https://leader-krishna-api.vercel.app/spam_visit?uid={uid}&region=ind&key=teamXKrishna',
            'L4':
            'https://leader-krishna-api.vercel.app/spam_visit?uid={uid}&region=ind&key=teamXKrishna',
            'current': ['L1'],  # Default API
        }
        with open(API_SETTINGS_FILE, 'w') as f:
            json.dump(default_settings, f)
    with open(API_SETTINGS_FILE, 'r') as f:
        return json.load(f)


# Function to save API settings to the file
def save_api_settings(settings):
    with open(API_SETTINGS_FILE, 'w') as f:
        json.dump(settings, f)


# Function to load promotions from the file
def load_promotions():
    if not os.path.exists(PROMOTIONS_FILE):
        with open(PROMOTIONS_FILE, 'w') as f:
            json.dump({}, f)  # Create the file if it doesn't exist
    with open(PROMOTIONS_FILE, 'r') as f:
        return json.load(f)


# Function to save promotions to the file
def save_promotions(promotions):
    with open(PROMOTIONS_FILE, 'w') as f:
        json.dump(promotions, f)


# Function to load VIP users from the file
def load_vip_users():
    if not os.path.exists(VIP_USERS_FILE):
        with open(VIP_USERS_FILE, 'w') as f:
            json.dump({}, f)  # Create the file if it doesn't exist
    with open(VIP_USERS_FILE, 'r') as f:
        return json.load(f)


# Function to save VIP users to the file
def save_vip_users(vip_users):
    with open(VIP_USERS_FILE, 'w') as f:
        json.dump(vip_users, f)


# Function to add a user to the VIP list
def add_vip_user(user_id):
    vip_users = load_vip_users()
    if str(user_id) not in vip_users:
        vip_users[str(user_id)] = True
        save_vip_users(vip_users)
        return True
    return False


# Function to remove a user from the VIP list
def remove_vip_user(user_id):
    vip_users = load_vip_users()
    if str(user_id) in vip_users:
        del vip_users[str(user_id)]
        save_vip_users(vip_users)
        return True
    return False


# Function to check if a user is VIP
def is_vip_user(user_id):
    vip_users = load_vip_users()
    return str(user_id) in vip_users


# Function to load analytics from the file
def load_analytics():
    if not os.path.exists(ANALYTICS_FILE):
        with open(ANALYTICS_FILE, 'w') as f:
            json.dump(
                {
                    "total_visits": 0,
                    "successful_visits": 0,
                    "failed_visits": 0,
                    "active_users": {},
                    "commands_used": {}
                }, f)  # Create the file if it doesn't exist
    with open(ANALYTICS_FILE, 'r') as f:
        return json.load(f)


# Function to save analytics to the file
def save_analytics(analytics):
    with open(ANALYTICS_FILE, 'w') as f:
        json.dump(analytics, f)


# Function to update visit stats
def update_visit_stats(successful, failed):
    analytics = load_analytics()
    analytics["total_visits"] += successful + failed
    analytics["successful_visits"] += successful
    analytics["failed_visits"] += failed
    save_analytics(analytics)


# Function to update active users
def update_active_user(user_id):
    analytics = load_analytics()
    analytics["active_users"][str(user_id)] = True
    save_analytics(analytics)


# Function to update command usage
def update_command_usage(command):
    analytics = load_analytics()
    if command in analytics["commands_used"]:
        analytics["commands_used"][command] += 1
    else:
        analytics["commands_used"][command] = 1
    save_analytics(analytics)


# Function to call the API
async def call_visit_api(uid, api_url):
    if not api_url:
        logging.error("API URL is empty.")
        return {}

    url = api_url.replace('{uid}', uid)
    logging.info(f"Calling API with URL: {url}")
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            if response.status == 200:
                return await response.json()
            else:
                logging.error(
                    f"API call failed with status: {response.status}")
                return {}


# Function to validate UID
def validate_uid(uid):
    # Remove all non-numeric characters
    uid = ''.join(filter(str.isdigit, uid))
    # Check if the UID is not empty and is numeric
    return bool(uid)


# Function to parse API response
def parse_api_response(api_response, api_key):
    if api_key == 'L1':
        return {
            'Name': api_response['message']['Name'],
            'UID': api_response['message']['UID'],
            'Successful': api_response['message']['Successful'],
            'Failed': api_response['message']['Failed'],
            'Time': api_response['message']['Time'],
            'Speed': api_response['message']['Speed'],
        }
    elif api_key == 'L2':
        status = json.loads(api_response['status'])
        return {
            'Name': 'N/A',
            'UID': 'N/A',
            'Successful': status['Views Success'],
            'Failed': status['Views Failed'],
            'Time': 'N/A',
            'Speed': 'N/A',
        }
    elif api_key == 'L3':
        status = json.loads(api_response['status'])
        return {
            'Name': 'N/A',
            'UID': 'N/A',
            'Successful': status['Views Success'],
            'Failed': status['Views Failed'],
            'Time': 'N/A',
            'Speed': 'N/A',
        }
    elif api_key == 'L4':
        status = json.loads(api_response['status'])
        return {
            'Name': 'N/A',
            'UID': 'N/A',
            'Successful': status['Views Success'],
            'Failed': status['Views Failed'],
            'Time': 'N/A',
            'Speed': 'N/A',
        }
    else:
        return {
            'Name': 'N/A',
            'UID': 'N/A',
            'Successful': 0,
            'Failed': 0,
            'Time': 'N/A',
            'Speed': 'N/A',
        }


# Function to fetch data from multiple APIs concurrently
async def fetch_data_from_apis(uid, api_keys):
    api_settings = load_api_settings()
    combined_response = {
        'Name': 'N/A',
        'UID': 'N/A',
        'Successful': 0,
        'Failed': 0,
        'Time': 'N/A',
        'Speed': 'N/A',
    }

    # Create a list of tasks for all API calls
    tasks = []
    for api_key in api_keys:
        api_url = api_settings.get(api_key, '')
        if not api_url:
            logging.warning(f"API key '{api_key}' has no URL configured.")
            continue

        logging.info(f"Preparing to call API: {api_key} with URL: {api_url}")
        tasks.append(call_visit_api(
            uid, api_url))  # Add the API call to the tasks list

    # Run all API calls concurrently
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Process the results
    for api_key, api_response in zip(api_keys, results):
        if isinstance(api_response, Exception):
            logging.error(f"API call failed for {api_key}: {api_response}")
            continue

        logging.info(f"API Response for {api_key}: {api_response}")
        parsed_response = parse_api_response(api_response, api_key)
        logging.info(f"Parsed Response for {api_key}: {parsed_response}")

        # Combine data
        if parsed_response['Name'] != 'N/A':
            combined_response['Name'] = parsed_response['Name']
        if parsed_response['UID'] != 'N/A':
            combined_response['UID'] = parsed_response['UID']
        combined_response['Successful'] += parsed_response['Successful']
        combined_response['Failed'] += parsed_response['Failed']
        if parsed_response['Time'] != 'N/A':
            combined_response['Time'] = parsed_response['Time']
        if parsed_response['Speed'] != 'N/A':
            combined_response['Speed'] = parsed_response['Speed']

    logging.info(f"Combined Response: {combined_response}")
    return combined_response


# Load authorized groups and API settings
authorized_groups = load_authorized_groups()
api_settings = load_api_settings()


# Handler for /allowgr command
@router.message(Command('allowgr'))
async def allow_group(message: types.Message):
    if message.from_user.id in ADMIN_USERS:
        args = message.text.split(' ', 1)
        if len(args) > 1:
            group_id = args[1].strip()
            if group_id.isdigit():
                group_id = int(group_id)
                if add_authorized_group(group_id):
                    await message.reply(
                        f"✅ Group {group_id} has been added to the authorized list."
                    )
                else:
                    await message.reply(
                        f"⚠️ Group {group_id} is already authorized.")
            else:
                await message.reply(
                    "❌ Invalid group ID. Group ID must be a number.")
        else:
            await message.reply(
                "❌ Invalid command format. Usage: /allowgr <group_id>")
    else:
        await message.reply("🚫 You are not authorized to use this command.")


# Handler for /visit command
@router.message(Command('visit'))
async def visit(message: types.Message):
    chat_id = message.chat.id
    if chat_id in authorized_groups:
        uid = message.text.split(' ', 1)[1] if len(message.text.split(
            ' ', 1)) > 1 else None
        if validate_uid(uid):
            # Send a "Processing..." message
            processing_message = await message.reply(
                f"⏳ Processing your request, @{message.from_user.username}...\n\n"
                "🌟 Please wait while we fetch your data!")

            # Fetch data from all selected APIs concurrently
            response = await fetch_data_from_apis(uid, api_settings['current'])

            # Update visit stats
            update_visit_stats(response['Successful'], response['Failed'])

            # Update active user
            update_active_user(message.from_user.id)

            # Update command usage
            update_command_usage('/visit')

            # Prepare the final response
            message_text = (
                f"🎮 FreeFire Visit Stats 🎮\n\n"
                f"👤 Name: <code>{response['Name']}</code>\n"
                f"🆔 UID: <code>{response['UID']}</code>\n"
                f"✅ Successful Visits: <code>{response['Successful']}</code>\n"
                f"❌ Failed Visits: <code>{response['Failed']}</code>\n"
                f"⏱️ Time Taken: <code>{response['Time']}</code>\n"
                f"⚡ Speed: <code>{response['Speed']}</code>\n\n"
                f"🎉 Data fetched successfully for @{message.from_user.username}!\n\n"
                f"🌟 Thank you for using the bot!")

            # Add promotion message if set
            promotions = load_promotions()
            promotion_message = promotions.get(str(chat_id), '')
            if promotion_message:
                message_text += "\n\n\n\n📢 Promotion:\n" + promotion_message

            # Edit the "Processing..." message with the final response
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_message.message_id,
                    text=message_text,
                    parse_mode=ParseMode.HTML)
                logging.info("Message edited successfully.")
            except Exception as e:
                logging.error(f"Failed to edit message: {e}")
        else:
            await message.reply("❌ Invalid UID!\n\n"
                                "📝 Usage: /visit <UID>\n\n"
                                "🔍 Example: /visit 123456789")
    else:
        await message.reply(
            "🚫 Unauthorized Group 🚫\n\n"
            "😕 This bot is not authorized to work in this group.\n"
            "📩 Please contact @ykmehh to add this group.")


# Handler for /vip command
@router.message(Command('vip'))
async def vip_command(message: types.Message):
    user_id = message.from_user.id
    if is_vip_user(user_id):
        await message.reply(
            "🌟 You are already a VIP user! Thank you for your support.")
    else:
        await message.reply(
            "🚀 Upgrade to VIP and enjoy exclusive benefits:\n\n"
            "✅ Higher daily visit limits\n"
            "⚡ Faster API processing\n"
            "🎁 Exclusive promotions\n\n"
            "Contact @ykmehh to upgrade!")


# Handler for /addvip command (Admin only)
@router.message(Command('addvip'))
async def add_vip_command(message: types.Message):
    if message.from_user.id in ADMIN_USERS:
        args = message.text.split(' ', 1)
        if len(args) > 1:
            user_id = args[1].strip()
            if user_id.isdigit():
                user_id = int(user_id)
                if add_vip_user(user_id):
                    await message.reply(
                        f"✅ User {user_id} has been added to the VIP list.")
                else:
                    await message.reply(f"⚠️ User {user_id} is already a VIP.")
            else:
                await message.reply(
                    "❌ Invalid user ID. User ID must be a number.")
        else:
            await message.reply(
                "❌ Invalid command format. Usage: /addvip <user_id>")
    else:
        await message.reply("🚫 You are not authorized to use this command.")


# Handler for /removevip command (Admin only)
@router.message(Command('removevip'))
async def remove_vip_command(message: types.Message):
    if message.from_user.id in ADMIN_USERS:
        args = message.text.split(' ', 1)
        if len(args) > 1:
            user_id = args[1].strip()
            if user_id.isdigit():
                user_id = int(user_id)
                if remove_vip_user(user_id):
                    await message.reply(
                        f"✅ User {user_id} has been removed from the VIP list."
                    )
                else:
                    await message.reply(f"⚠️ User {user_id} is not a VIP.")
            else:
                await message.reply(
                    "❌ Invalid user ID. User ID must be a number.")
        else:
            await message.reply(
                "❌ Invalid command format. Usage: /removevip <user_id>")
    else:
        await message.reply("🚫 You are not authorized to use this command.")


# Handler for /analytics command (Admin only)
@router.message(Command('analytics'))
async def analytics_command(message: types.Message):
    if message.from_user.id in ADMIN_USERS:
        analytics = load_analytics()
        total_visits = analytics["total_visits"]
        successful_visits = analytics["successful_visits"]
        failed_visits = analytics["failed_visits"]
        active_users = len(analytics["active_users"])
        commands_used = analytics["commands_used"]

        # Format the analytics message
        analytics_text = ("📊 *Bot Analytics* 📊\n\n"
                          f"🔹 Total Visits: {total_visits}\n"
                          f"🔹 Successful Visits: {successful_visits}\n"
                          f"🔹 Failed Visits: {failed_visits}\n"
                          f"🔹 Active Users: {active_users}\n\n"
                          "🔹 *Commands Used*:\n")
        for command, count in commands_used.items():
            analytics_text += f"• {command}: {count}\n"

        await message.reply(analytics_text, parse_mode=ParseMode.MARKDOWN)
    else:
        await message.reply("🚫 You are not authorized to use this command.")


# Handler for /setapi command
@router.message(Command('setapi'))
async def set_api(message: types.Message):
    if message.from_user.id in ADMIN_USERS:
        args = message.text.split(' ', 1)
        if len(args) > 1:
            api_keys = args[1].strip().split('+')
            valid_api_keys = ['L1', 'L2', 'L3', 'L4']
            invalid_keys = [
                key for key in api_keys if key not in valid_api_keys
            ]
            if not invalid_keys:
                api_settings['current'] = api_keys
                save_api_settings(api_settings)
                await message.reply(
                    f"✅ API settings updated to: {', '.join(api_keys)}")
            else:
                await message.reply(
                    f"❌ Invalid API keys: {', '.join(invalid_keys)}. Valid keys are: {', '.join(valid_api_keys)}"
                )
        else:
            await message.reply(
                "❌ Invalid command format. Usage: /setapi <L1+L2+...>")
    else:
        await message.reply("🚫 You are not authorized to use this command.")


# Handler for /setpromotion command
@router.message(Command('setpromotion'))
async def set_promotion(message: types.Message):
    if message.from_user.id in ADMIN_USERS or message.from_user.id in VICE_ADMIN_USERS:
        args = message.text.split(' ', 1)
        if len(args) > 1:
            text_parts = args[1].strip().split(' ', 1)

            # Check if the first part is a group ID
            if len(text_parts) > 1 and text_parts[0].startswith(
                    '-') and text_parts[0][1:].isdigit():
                target_chat_id = text_parts[0]
                promotion_text = text_parts[1].strip()
            else:
                # Use current chat ID if no specific group ID is provided
                target_chat_id = str(message.chat.id)
                promotion_text = args[1].strip()

            promotions = load_promotions()
            promotions[target_chat_id] = promotion_text
            save_promotions(promotions)

            user_type = "admin" if message.from_user.id in ADMIN_USERS else "vice admin"
            if target_chat_id == str(message.chat.id):
                await message.reply(
                    f"✅ Promotion message has been set for this group by {user_type}."
                )
            else:
                await message.reply(
                    f"✅ Promotion message has been set for group {target_chat_id} by {user_type}."
                )
        else:
            await message.reply(
                "❌ Invalid command format. Usage:\n/setpromotion <text>\nor\n/setpromotion -GROUP_ID <text>"
            )
    else:
        await message.reply("🚫 You are not authorized to use this command.")


# Handler for /clearpromotion command
@router.message(Command('clearpromotion'))
async def clear_promotion(message: types.Message):
    if message.from_user.id in ADMIN_USERS:
        args = message.text.split(' ', 1)
        # Check if a specific group ID is provided
        if len(args) > 1 and args[1].strip().startswith(
                '-') and args[1].strip()[1:].isdigit():
            target_chat_id = args[1].strip()
        else:
            target_chat_id = str(message.chat.id)

        promotions = load_promotions()
        if target_chat_id in promotions:
            del promotions[target_chat_id]
            save_promotions(promotions)

            if target_chat_id == str(message.chat.id):
                await message.reply(
                    "✅ Promotion message has been cleared for this group.")
            else:
                await message.reply(
                    f"✅ Promotion message has been cleared for group {target_chat_id}."
                )
        else:
            if target_chat_id == str(message.chat.id):
                await message.reply(
                    "ℹ️ No promotion message was set for this group.")
            else:
                await message.reply(
                    f"ℹ️ No promotion message was set for group {target_chat_id}."
                )
    else:
        await message.reply("🚫 You are not authorized to use this command.")


# Handler for /help command
@router.message(Command('help'))
async def help_command(message: types.Message):
    chat_id = message.chat.id
    is_authorized = chat_id in authorized_groups
    is_admin = message.from_user.id in ADMIN_USERS
    is_vice_admin = message.from_user.id in VICE_ADMIN_USERS

    help_text = "🤖 *Bot Commands* 🤖\n\n"

    # Commands for all users in authorized groups
    if is_authorized:
        help_text += "*User Commands:*\n"
        help_text += "• /visit <UID> - Get visit stats for a Free Fire UID (uses all selected APIs)\n"
        help_text += "• /help - Show this help message\n"
        help_text += "• /status - Check bot and API status\n"
        help_text += "• /about - Information about the bot\n"
        help_text += "• /start - Get welcome message\n"
        help_text += "• /ping - Check bot response time\n"
        help_text += "• /stats - View bot statistics\n\n"

    # Commands for vice admins
    if is_vice_admin and not is_admin:
        help_text += "*Vice Admin Commands:*\n"
        help_text += "• /setpromotion <text> - Set promotion text for current group\n"
        help_text += "• /setpromotion -GROUP_ID <text> - Set promotion for specific group\n\n"

    # Commands for admins only
    if is_admin:
        help_text += "*Admin Commands:*\n"
        help_text += "• /allowgr <group_id> - Authorize a group to use the bot\n"
        help_text += "• /getgroupid - Get the current group ID\n"
        help_text += "• /setpromotion <text> - Set promotion text for current group\n"
        help_text += "• /clearpromotion - Clear promotion text for current group\n"
        help_text += "• /{number}visit <UID> - Send multiple visit requests at once\n\n"

    if not is_authorized and not is_admin and not is_vice_admin:
        help_text += "🚫 This bot is not authorized to work in this group.\n"
        help_text += "📩 Please contact @ykmehh to add this group."

    await message.reply(help_text, parse_mode=ParseMode.MARKDOWN)


# Handler for /status command
@router.message(Command('status'))
async def status_command(message: types.Message):
    chat_id = message.chat.id
    is_admin = message.from_user.id in ADMIN_USERS

    if chat_id in authorized_groups:
        status_text = "🔄 *Bot Status* 🔄\n\n"
        status_text += "✅ Bot is running\n"
        status_text += f"✅ Group is authorized (ID: {chat_id})\n\n"

        # Show API details only to admins
        if is_admin:
            # Get the current API settings
            current_apis = api_settings.get('current', [])
            api_urls = {
                api: api_settings.get(api, "Not configured")
                for api in current_apis
            }

            status_text += "📊 *API Status* 📊\n"
            status_text += "ℹ️ All selected APIs are used for each request, results are combined\n"
            for api, url in api_urls.items():
                status_text += f"• {api}: {'✅ Configured' if url else '❌ Not configured'}\n"

            status_text += f"\n*Current APIs:* {', '.join(current_apis)}"
        else:
            status_text += "✅ Service is operational\n"
            status_text += "✅ Visit requests are being processed normally"

        await message.reply(status_text, parse_mode=ParseMode.MARKDOWN)
    else:
        await message.reply(
            "🚫 Unauthorized Group 🚫\n\n"
            "😕 This bot is not authorized to work in this group.\n"
            "📩 Please contact @ykmehh to add this group.")


# Handler for /about command
@router.message(Command('about'))
async def about_command(message: types.Message):
    is_admin = message.from_user.id in ADMIN_USERS

    about_text = "💠 *FreeFire Visit Bot* 💠\n\n"
    about_text += "This bot helps you increase visit count for FreeFire accounts.\n\n"
    about_text += "🔷 *Features*:\n"
    about_text += "• Fast visit processing\n"

    # Only show API related information to admins
    if is_admin:
        about_text += "• Multiple API support\n"

    about_text += "• Group-specific promotions\n"
    about_text += "• Detailed visit statistics\n\n"
    about_text += "👨‍💻 Developed by: @ykmehh"

    await message.reply(about_text, parse_mode=ParseMode.MARKDOWN)


# Handler for /stats command
@router.message(Command('stats'))
async def stats_command(message: types.Message):
    chat_id = message.chat.id
    if chat_id in authorized_groups:
        # Count total authorized groups
        total_groups = len(authorized_groups)

        # Count total unique promotions
        promotions = load_promotions()
        total_promotions = len(promotions)

        stats_text = "📊 *Bot Statistics* 📊\n\n"
        stats_text += f"🔹 Total authorized groups: {total_groups}\n"
        stats_text += f"🔹 Total active promotions: {total_promotions}\n"
        stats_text += f"🔹 Available APIs: {len([api for api in api_settings if api not in ['current'] and api_settings[api]])}\n"

        await message.reply(stats_text, parse_mode=ParseMode.MARKDOWN)
    else:
        await message.reply(
            "🚫 Unauthorized Group 🚫\n\n"
            "😕 This bot is not authorized to work in this group.\n"
            "📩 Please contact @ykmehh to add this group.")


# Handler for /start command
@router.message(Command('start'))
async def start_command(message: types.Message):
    chat_id = message.chat.id
    user_name = message.from_user.first_name

    welcome_text = f"👋 Hello, {user_name}!\n\n"
    welcome_text += "Welcome to the *FreeFire Visit Bot*. "

    if chat_id in authorized_groups:
        welcome_text += "This group is authorized to use all bot features.\n\n"
        welcome_text += "To get started, try these commands:\n"
        welcome_text += "• /visit <UID> - Get visit stats for a Free Fire UID\n"
        welcome_text += "• /help - Show all available commands\n"
        welcome_text += "• /about - Learn more about this bot"
    else:
        welcome_text += "⚠️ This group is not authorized yet.\n\n"
        welcome_text += "To use this bot, please contact @ykmehh to authorize your group."

    await message.reply(welcome_text, parse_mode=ParseMode.MARKDOWN)


# Handler for /ping command
@router.message(Command('ping'))
async def ping_command(message: types.Message):
    start_time = asyncio.get_event_loop().time()
    ping_msg = await message.reply("🏓 Pinging...")

    end_time = asyncio.get_event_loop().time()
    ping_time = round((end_time - start_time) * 1000, 2)

    await bot.edit_message_text(chat_id=message.chat.id,
                                message_id=ping_msg.message_id,
                                text=f"🏓 Pong! Response time: {ping_time}ms")


# Handler for custom visit command with pattern /{number}visit {uid}
@router.message()
async def custom_visit_command(message: types.Message):
    # Check if message starts with a number followed by "visit"
    text = message.text.strip()
    import re
    match = re.match(r'^/(\d+)visit\s+(\d+)$', text)

    if match:
        num_requests = int(match.group(1))
        uid = match.group(2)

        # Only allow admin users to use this command
        if message.from_user.id in ADMIN_USERS:
            # Limit the number of requests to 20 for safety
            if num_requests > 20:
                await message.reply(
                    "⚠️ Maximum number of visits is limited to 20 for safety reasons."
                )
                return

            # Send a processing message
            processing_message = await message.reply(
                f"⏳ Processing {num_requests} visit requests for UID {uid}...\n\n"
                f"🌟 This may take some time. Please wait!")

            # Make multiple API calls
            total_successful = 0
            total_failed = 0
            name = "N/A"
            uid_value = uid

            for i in range(num_requests):
                response = await fetch_data_from_apis(uid,
                                                      api_settings['current'])

                # Update totals
                total_successful += response['Successful']
                total_failed += response['Failed']

                # Get name and UID from the first successful response
                if response['Name'] != 'N/A' and name == 'N/A':
                    name = response['Name']
                if response['UID'] != 'N/A':
                    uid_value = response['UID']

            # Prepare the final response
            result_text = (
                f"🎮 Multiple FreeFire Visits Report 🎮\n\n"
                f"👤 Name: <code>{name}</code>\n"
                f"🆔 UID: <code>{uid_value}</code>\n"
                f"🔢 Requests made: <code>{num_requests}</code>\n"
                f"✅ Total Successful Visits: <code>{total_successful}</code>\n"
                f"❌ Total Failed Visits: <code>{total_failed}</code>\n\n"
                f"🎉 Multiple visit requests completed for @{message.from_user.username}!\n\n"
                f"🌟 Thank you for using the bot!")

            # Edit the processing message with results
            try:
                await bot.edit_message_text(
                    chat_id=message.chat.id,
                    message_id=processing_message.message_id,
                    text=result_text,
                    parse_mode=ParseMode.HTML)
            except Exception as e:
                logging.error(f"Failed to edit message: {e}")

            # Return to prevent the message from being processed by other handlers
            return

    # If not a custom visit command, treat as unhandled message
    logging.warning(
        f"Unhandled message: {message.text} from {message.from_user.username} (ID: {message.from_user.id})"
    )


# Start the bot
async def main():
    keep_alive()  # Start the web server to keep the bot alive
    await bot.delete_webhook(drop_pending_updates=True)  # Delete the webhook
    await dp.start_polling(bot)  # Start polling


if __name__ == '__main__':
    asyncio.run(main())  # Run the bot using asyncio
